export default class Operator {
  constructor(public readonly id: string, public name: number) {}
}
