export const BLURRED_BG = {
  backdropFilter: "blur(3px)",
  backgroundColor: "#ffffff55",
};
