import "./App.css";
import JourneyPage from "./Journey/Journey.page";

function App() {
  return (
    <div>
      <JourneyPage />
    </div>
  );
}

export default App;
